  /* Script for creating the DB */
  CREATE DATABASE IF NOT EXISTS academic_records
    CHARACTER SET utf8mb4
    COLLATE utf8mb4_general_ci;
  USE academic_records;

  SET FOREIGN_KEY_CHECKS = 0;

  DROP TABLE IF EXISTS course_grade_components;
  DROP TABLE IF EXISTS course_tags;
  DROP TABLE IF EXISTS courses;
  DROP TABLE IF EXISTS grade_components;
  DROP TABLE IF EXISTS tags;
  DROP TABLE IF EXISTS semesters;
  DROP TABLE IF EXISTS years;
  DROP TABLE IF EXISTS users;
  DROP TABLE IF EXISTS programs;
  DROP TABLE IF EXISTS institutions;

  SET FOREIGN_KEY_CHECKS = 1;


  CREATE TABLE institutions (
    name VARCHAR(255) NOT NULL PRIMARY KEY
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

  CREATE TABLE programs (
    name VARCHAR(255) NOT NULL PRIMARY KEY
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

  CREATE TABLE users (
    email            VARCHAR(255) NOT NULL PRIMARY KEY,
    first_name       VARCHAR(255) NOT NULL,
    last_name        VARCHAR(255) NOT NULL,
    password    VARCHAR(255) NOT NULL,
    institution_name VARCHAR(255),
    program_name     VARCHAR(255),
    start_year       YEAR,
    CONSTRAINT chk_email_format
      CHECK (email REGEXP '^[A-Za-z0-9._-]+@[A-Za-z0-9.-]+\.[A-Za-z]{1,}$'),
    CONSTRAINT chk_password_length
      CHECK (CHAR_LENGTH(password) >= 6),
    CONSTRAINT fk_users_institution
      FOREIGN KEY (institution_name)
      REFERENCES institutions(name)
      ON UPDATE CASCADE
      ON DELETE SET NULL,
    CONSTRAINT fk_users_program
      FOREIGN KEY (program_name)
      REFERENCES programs(name)
      ON UPDATE CASCADE
      ON DELETE SET NULL
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

  CREATE TABLE semesters (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

  CREATE TABLE years (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

  CREATE TABLE courses (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    course_name VARCHAR(255) NOT NULL,
    credits DECIMAL(3,1) NOT NULL,
    CONSTRAINT chk_credits_step
      CHECK (credits * 2 = FLOOR(credits * 2)),
    semester_id INT NOT NULL,
    year_id INT NOT NULL,
    grade DECIMAL(5,2),
    real_grade DECIMAL(5,2), 
    bonus INT,
    is_binary BOOLEAN DEFAULT FALSE,
    user_email VARCHAR(255),
    CONSTRAINT fk_courses_user
      FOREIGN KEY (user_email)
      REFERENCES users(email)
      ON UPDATE CASCADE
      ON DELETE CASCADE,
    CONSTRAINT fk_courses_semester
      FOREIGN KEY (semester_id)
      REFERENCES semesters(id)
      ON UPDATE CASCADE
      ON DELETE CASCADE,
    CONSTRAINT fk_courses_year
      FOREIGN KEY (year_id)
      REFERENCES years(id)
      ON UPDATE CASCADE
      ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


  CREATE TABLE tags (
    tag VARCHAR(100) NOT NULL PRIMARY KEY
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

  CREATE TABLE course_tags (
    course_id INT NOT NULL,
    tag       VARCHAR(100) NOT NULL,
    PRIMARY KEY (course_id, tag),
    CONSTRAINT fk_ct_course
      FOREIGN KEY (course_id)
      REFERENCES courses(id)
      ON UPDATE CASCADE
      ON DELETE CASCADE,
    CONSTRAINT fk_ct_tag
      FOREIGN KEY (tag)
      REFERENCES tags(tag)
      ON UPDATE CASCADE
      ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

  CREATE TABLE grade_components (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    component VARCHAR(100) NOT NULL UNIQUE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;


  CREATE TABLE course_grade_components (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY, 
    course_id INT NOT NULL,
    component INT NOT NULL,
    weight DECIMAL(5,2) NOT NULL DEFAULT 0,
    grade DECIMAL(5,2) DEFAULT NULL,
    CONSTRAINT fk_cgc_course
      FOREIGN KEY (course_id)
      REFERENCES courses(id)
      ON UPDATE CASCADE
      ON DELETE CASCADE,
    CONSTRAINT fk_cgc_component
      FOREIGN KEY (component)
      REFERENCES grade_components(id)
      ON UPDATE CASCADE
      ON DELETE CASCADE
  ) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;