import express from 'express';
import db from '../db/db.js'; 

const router = express.Router();
// Get user details for authenticated user (using email from cookie)
router.get('/user-details', (req, res) => {
    const userEmail = req.userEmail;
    const query = `
        SELECT
            first_name,
            last_name,
            institution_name,
            program_name,
            start_year
        FROM users
        WHERE email = ?
    `;
    db.execute(query, [userEmail], (error, results) => {
        if (error) {
            return res.status(500).json({ message: "Internal server error fetching user details." });
        }
        if (results && results.length > 0) {
            return res.json(results[0]);
        }         
        else {
            return res.status(404).json({ message: "User details not found." });
        }
    });
});

export default router;