export default {
    host: 'localhost',
    user: 'root',
    password: '123123',
    database: 'academic_records',
};

