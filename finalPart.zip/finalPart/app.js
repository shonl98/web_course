import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';
import cookieParser from 'cookie-parser';
import coursesRouter from './routes/courses_routes.js';
import tagsRouter from './routes/tags_routes.js';
import loginRouter from './routes/login.js';
import registerRouter from './routes/Register.js'; 
import userRouter from './routes/user_routes.js';   

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);
const app = express();

// Basic Middlewares 
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(cookieParser());

// Check authentication via cookies
const isAuthenticated = (req, res, next) => {
    const userEmail = req.cookies.userAuth;
    if (!userEmail) { // If no auth cookie, user is not authenticated
        return res.status(401).json({ error: 'Not Authenticated. Please log in.' });
    }
    // If authenticated, attach email to the request object for other routes to use
    req.userEmail = userEmail;
    next();
};

// if user logged in and asking home page - redirect him to connected home page 
app.get('/', (req, res, next) => {
  if (req.cookies.userAuth) {
    res.redirect('/Home_connected.html');
  } else {
    next();
  }
});

app.use(express.static(path.join(__dirname, 'public')));

// Public Routes (do not require authentication) 
app.use('/login', loginRouter);
app.use('/api/tags', tagsRouter);
app.use('/Register', registerRouter);

// Logout Endpoint - delete cookie
app.post('/logout', (req, res) => {
    const cookieOptions = {
        httpOnly: true,
        secure: process.env.NODE_ENV === 'production',
        sameSite: 'Strict',
        path: '/'
    };
    res.clearCookie('userAuth', cookieOptions);
    res.status(200).json({ message: 'Logged out successfully!' });
    console.log('User logged out. Cookie "userAuth" cleared.');
});

// Require authentication before accessing user and courses
app.use('/api', isAuthenticated, userRouter);
app.use('/api/courses', isAuthenticated, coursesRouter);

// Server Activation 
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
    console.log(`Server running on http://localhost:${PORT}`);
});