// statistics_page_script.js

// Runs when DOM is fully loaded
document.addEventListener("DOMContentLoaded", () => {
    var coursesList = []; //hold the main list of courses from the server
    var TAGS = []; // hold the list of all possible tags from the server
    // Chart instances - so we can destroy and recreate them
    let componentChart = null;
    let tagsBarChart = null;
    let rangePieChart = null;

    // Handle back-forward cache
    window.addEventListener('pageshow', function (event) {
        if (event.persisted) {
            location.reload();
        }
    });
    // Fetches the courses for the currently authenticated user. 
    // Redirects to login if user is not authenticated.
    async function fetchMyCourses() {
        try {
            const response = await fetch('/api/courses');

            // Handle unauthorized access
            if (response.status === 401) {
                alert("ההתחברות פגה או שאינך מחובר. אנא התחבר מחדש.");
                window.location.href = '/ConnectPage.html'; // Redirect to login
                return null;
            }

            if (!response.ok) {
                throw new Error(`Server error: ${response.status}`);
            }
            return await response.json();
        } catch (error) {
            return null;
        }
    }
    // Handle user logout
    document.getElementById('logout').addEventListener('click', function (event) {
        event.preventDefault(); // Prevent default link behavior – stop the browser from navigating before logout request completes
        fetch('/logout', {// Send logout request to server
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            }
        })
            .then(response => {
                if (response.ok) {
                    window.location.href = 'index.html'; // Redirect after logout
                } else {
                    alert('התנתקות נכשלה. אנא נסה שוב.');
                }
            })
            .catch(error => {
                alert('אירעה שגיאה. אנא נסה שוב מאוחר יותר.');
            });
    });

     // Fetch available tags from server
    async function fetchTags() {
        try {
            const res = await fetch("/api/tags");
            if (!res.ok) throw new Error(`Server error fetching tags: ${res.status}`);// Handle server error
            const data = await res.json();
            return data && Array.isArray(data.tags) ? data.tags : [];// Tranform the answer to tags array

        } catch (e) {
            return [];
        }
    }

    // Initialize the page
    async function initializePage() {
        const [fetchedTags, fetchedCourses] = await Promise.all([
            fetchTags(),
            fetchMyCourses()
        ]);
        if (fetchedCourses === null) {
            return;
        }
        TAGS = fetchedTags || [];
        coursesList = fetchedCourses || [];
        updateSummaryStats(); // Update total credits and average on UI
        processAndRenderAllElements();
    }

    // Calculate total credits and weighted avg grade
    function calculateSummaryStats() {
        let totalNakaz = 0;
        let totalWeightedSum = 0;
        let totalNakazForAverage = 0;

        coursesList.forEach(course => {
            const nakaz = parseFloat(course.credits);
            if (!isNaN(nakaz)) {
                totalNakaz += nakaz;
            }
            // Only include non-binary courses in average calculation if grade and nakaz are valid numbers
            if (!course.binaryChecked) {
                const grade = parseFloat(course.real_grade);

                if (!isNaN(grade) && !isNaN(nakaz)) {
                    totalWeightedSum += grade * nakaz;
                    totalNakazForAverage += nakaz;
                } 
            }
        });
        const currentAverage = totalNakazForAverage > 0 ? (totalWeightedSum / totalNakazForAverage) : 0;
        return {
            totalNakaz: totalNakaz.toFixed(1), // Format to one decimal place
            currentAverage: currentAverage.toFixed(1) // Format to one decimal place
        };
    }

  // Update total credits and average on UI
    function updateSummaryStats() {
        const stats = calculateSummaryStats();
        const totalNakazElement = document.getElementById('total-nakaz');
        const avgScoreElement = document.getElementById('avg-score');
        if (totalNakazElement) {
            totalNakazElement.textContent = stats.totalNakaz;
        }
        if (avgScoreElement) {
            avgScoreElement.textContent = stats.currentAverage;
        }
    }

 // function that handles data and updates the charts and page
    function processAndRenderAllElements() {
        const componentChartCanvas = document.getElementById('componentPieChart');
        const courseSelectWrapper = document.querySelector('.course-select-wrapper');
        const weightedScoreElement = document.getElementById("weighted-score");

        const componentChartCard = componentChartCanvas ? componentChartCanvas.closest('.chart-card') : null;
        // --- Component Breakdown Chart ---
        const eligibleCoursesForComponents = populateComponentCourseSelect();

        // Handle the display based on whether there are eligible courses
        if (eligibleCoursesForComponents.length > 0) {
            if (componentChartCanvas) componentChartCanvas.style.display = '';
            if (courseSelectWrapper) courseSelectWrapper.style.display = '';
            if (weightedScoreElement) weightedScoreElement.style.display = '';

            // Remove any previous "no data" message
            const noDataMessage = componentChartCard ? componentChartCard.querySelector('.no-component-data-message') : null;
            if (noDataMessage) noDataMessage.remove();

            // Select the default option initially, prompting user selection
            const courseSelectElement = document.getElementById("course-select");
            if (courseSelectElement && courseSelectElement.options.length > 0) {
                courseSelectElement.value = ""; // Set to the empty default value
                if (weightedScoreElement) weightedScoreElement.textContent = 'בחר קורס מהרשימה.';
            } else {
                if (weightedScoreElement) weightedScoreElement.textContent = 'בחר קורס מהרשימה.';
            }
        } else {
            // Hide elements 
            if (componentChartCanvas) componentChartCanvas.style.display = 'none';
            if (courseSelectWrapper) courseSelectWrapper.style.display = 'none'; 
            if (weightedScoreElement) weightedScoreElement.style.display = 'none'; 

            // Add a "no data" message if it doesn't exist already
            if (componentChartCard) {
                let noDataMessage = componentChartCard.querySelector('.no-component-data-message');
                if (!noDataMessage) {
                    noDataMessage = document.createElement('p');
                    noDataMessage.className = 'no-component-data-message'; // Add a class for easy selection
                    noDataMessage.textContent = "אין קורסים עם פירוט רכיבים להצגה.";

                    const chartTitle = componentChartCard.querySelector('h3');
                    if (chartTitle) {
                        chartTitle.after(noDataMessage); // Insert after the title
                    } else {
                        componentChartCard.appendChild(noDataMessage); // Append to the card if no chartTitle found
                    }
                }
            }
            // Destroy the chart instance if it exists
            if (componentChart) {
                componentChart.destroy();
                componentChart = null; // Clear the reference
            }
        }
        // --- Grade Distribution Chart ---
        const gradeDistributionData = calculateGradeDistribution();
        renderGradeDistributionChart(gradeDistributionData);

        // --- Average by Tag Chart ---
        renderSummaryTagCheckboxes();
        // Ensure checkboxes are rendered before trying to read their state
        // Use requestAnimationFrame to allow the DOM to update after rendering checkboxes
        requestAnimationFrame(() => {
            const initialSelectedTags = [...document.querySelectorAll('#summary-tag-options input:checked')].map(cb => cb.value);
            renderTagsBarChart(initialSelectedTags);
            setupTagDropdown(); // Setup dropdown with checkboxes for filtering tags
        });
        // --- Other UI elements ---
        const yearElement = document.getElementById("year");
        if (yearElement) yearElement.textContent = new Date().getFullYear();
    }


    // Populates the course dropdown with non-binary courses that have components
    //return An array of eligible courses that were added to the select.
    function populateComponentCourseSelect() {
        const select = document.getElementById("course-select");
        if (!select) {
            return [];
        }
        select.innerHTML = ''; // Clear existing options
        const eligibleCourses = coursesList.filter(course =>
            !course.binaryChecked && course.components && Array.isArray(course.components) && course.components.length > 0
        );
        // Add a default "Select Course" option if there are eligible courses
        if (eligibleCourses.length > 0) {
            const defaultOption = document.createElement("option");
            defaultOption.value = ""; // Use an empty value
            defaultOption.textContent = "בחר קורס..."; // Default text
            select.appendChild(defaultOption);

            eligibleCourses.forEach((course, index) => {
                const option = document.createElement("option");
                // Store the index in the eligibleCourses array
                option.value = index;
                option.textContent = course.name;
                select.appendChild(option);
            });
        }
        return eligibleCourses;
    }

    /**
     * Renders the pie chart showing component breakdown for a selected course.
     * @param {string|number} courseValue - The value from the select option (index or empty string).
     * @param {Array} eligibleCourses - The list of courses eligible for component breakdown.
     */

    // Renders a pie chart showing component breakdown for a selected course.
    function renderComponentChart(courseValue, eligibleCourses) {
        const ctx = document.getElementById("componentPieChart");
        const weightedScoreElement = document.getElementById("weighted-score");

        // Clear previous chart and score display
        if (componentChart) componentChart.destroy();
        if (weightedScoreElement) weightedScoreElement.textContent = '';

        if (!ctx) {
            if (weightedScoreElement) weightedScoreElement.textContent = '';
            return;
        }
        const context = ctx.getContext("2d");
        // Clear canvas manually if destroying doesn't fully clear on some browsers
        context.clearRect(0, 0, ctx.width, ctx.height);

        if (courseValue === "" || eligibleCourses.length === 0) {
            // If no valid course is selected (-default option is selected or no eligible courses for component chart)
            if (weightedScoreElement) weightedScoreElement.textContent = eligibleCourses.length > 0 ? 'בחר קורס מהרשימה.' : 'אין קורסים עם פירוט רכיבים להצגה.';
            if (weightedScoreElement) weightedScoreElement.style.display = ''; // Ensure message is visible
            return;
        }
        const courseIndex = parseInt(courseValue, 10); // Convert thr coursevalueto integer index to access course in array

        if (isNaN(courseIndex) || courseIndex < 0 || courseIndex >= eligibleCourses.length) {
            if (weightedScoreElement) weightedScoreElement.textContent = 'שגיאה בבחירת קורס.';
            if (weightedScoreElement) weightedScoreElement.style.display = ''; 
            return;
        }
        const course = eligibleCourses[courseIndex];
        // Ensure components have data before rendering
        if (!course.components || !Array.isArray(course.components) || course.components.length === 0) {
            if (weightedScoreElement) weightedScoreElement.textContent = 'אין פירוט רכיבים לקורס זה.'; // Show message
            if (weightedScoreElement) weightedScoreElement.style.display = '';
            return;
        }
        const data = {  // Prepare data object for pie chart
            labels: course.components.map((c) => c.component),
            datasets: [{
                data: course.components.map((c) => parseFloat(c.weight) || 0), // Ensure weight is a number
                backgroundColor: ["#f39c12", "#2980b9", "#27ae60", "#c0392b", "#8e44ad"],
            }],
        };

        componentChart = new Chart(context, { // Create the pie chart 
            type: "pie",
            data: data,
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'top', labels: { font: { size: 16 } } },
                    tooltip: { callbacks: { label: (c) => `${c.label}: ${c.raw}%` } }
                },
            },
        });

        // Show the numeric grade result under the chart
        const numericGrade = parseFloat(course.real_grade); 
        if (weightedScoreElement) {
            if (!isNaN(numericGrade)) {
                weightedScoreElement.textContent = `ציון משוקלל: ${numericGrade.toFixed(1)}`;
            } else {
                weightedScoreElement.textContent = 'ציון משוקלל: לא זמין';
            }
            weightedScoreElement.style.display = ''; 
        }
    }



     //Calculates the distribution of grades into predefined ranges.
    function calculateGradeDistribution() {
        const ranges = {
            "90-100": 0, "80-89": 0, "70-79": 0,
            "60-69": 0, "55-59": 0, "פחות מ-55": 0
        };
        coursesList.forEach(course => {
            // Only include non-binary courses with a valid numeric grade
            if (!course.binaryChecked) {
                const grade = parseFloat(course.real_grade);
                if (!isNaN(grade)) {
                    if (grade >= 90) ranges["90-100"]++;
                    else if (grade >= 80) ranges["80-89"]++;
                    else if (grade >= 70) ranges["70-79"]++;
                    else if (grade >= 60) ranges["60-69"]++;
                    else if (grade >= 55) ranges["55-59"]++;
                    else ranges["פחות מ-55"]++;
                }
            }
        });
        return ranges;
    }

    //Renders the pie chart for grade distribution.
    function renderGradeDistributionChart(rangeData) {
        const ctx = document.getElementById("rangePieChart");
        if (!ctx) {
            return;
        }
        const context = ctx.getContext("2d");
        if (rangePieChart) rangePieChart.destroy(); // Destroy previous chart instance

        // Check if there is any data to display
        const totalGrades = Object.values(rangeData).reduce((sum, count) => sum + count, 0);

        if (totalGrades === 0) {
            context.clearRect(0, 0, ctx.width, ctx.height); // Clear canvas
            return;
        }
        // Create and render the new pie chart
        rangePieChart = new Chart(context, {
            type: "pie",
            data: {
                labels: Object.keys(rangeData),
                datasets: [{
                    data: Object.values(rangeData),
                    backgroundColor: ["#16a085", "#27ae60", "#2ecc71", "#f1c40f", "#e67e22", "#e74c3c"],
                }],
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: { position: 'top', labels: { font: { size: 16 } } },
                },
            },
        });
    }
    
    //Calculates the average grade for each tag across all non-binary courses.
    function calculateAveragesByTag() {
        const tagSums = {};// Holds sum of grades per tag
        const tagCounts = {}; // Holds number of courses per tag

        coursesList.forEach(course => {
            // Only include non-binary courses with valid grades and tags
            if (!course.binaryChecked && course.tags) {
                const numericGrade = parseFloat(course.real_grade);
                if (!isNaN(numericGrade)) {
                    const courseTags = Array.isArray(course.tags) ? course.tags : (typeof course.tags === 'string' ? course.tags.split(',').map(tag => tag.trim()) : []);

                    courseTags.forEach(tag => {
                        if (tag && tag.trim() !== '') { // Ensure tag is not empty or just whitespace
                            const trimmedTag = tag.trim();
                            tagSums[trimmedTag] = (tagSums[trimmedTag] || 0) + numericGrade;
                            tagCounts[trimmedTag] = (tagCounts[trimmedTag] || 0) + 1;
                        }
                    });
                }
            }
        });
        // Compute average for each tag
        const tagAverages = {};
        for (const tag in tagCounts) {
            if (tagCounts[tag] > 0) { // Avoid division by zero
                tagAverages[tag] = (tagSums[tag] / tagCounts[tag]);
            }
        }
        return tagAverages;
    }

  
    //Renders a bar chart showing the average grades for the selected tags.
    function renderTagsBarChart(selectedTags) {
        const tagsData = calculateAveragesByTag();
        // Filter for selected tags that actually have data in tagsData
        const labels = selectedTags.filter(tag => tagsData.hasOwnProperty(tag));
        const dataValues = labels.map(tag => tagsData[tag]);
        const ctx = document.getElementById("tagsBarChart");

        if (!ctx) {
            return;
        }
        const context = ctx.getContext("2d");
        if (tagsBarChart) tagsBarChart.destroy(); // Destroy previous chart instance

        if (labels.length === 0) {
            context.clearRect(0, 0, ctx.width, ctx.height); // Clear canvas
            return;
        }
        // Create and display the bar chart
        tagsBarChart = new Chart(context, {
            type: "bar",
            data: {
                labels: labels,
                datasets: [{
                    label: "ציון ממוצע",
                    data: dataValues,
                    backgroundColor: "#00796b",
                    borderRadius: 4,
                }],
            },
            options: {
                responsive: true, maintainAspectRatio: false,
                plugins: { legend: { display: false } },
                scales: {
                    y: { beginAtZero: false, suggestedMin: 50, suggestedMax: 100, ticks: { font: { size: 14 } } },
                    x: { ticks: { font: { size: 14 } }, grid: { display: false } },
                },
            },
        });
    }

    // Renders the checkboxes used for filtering tags in the summary bar chart
    function renderSummaryTagCheckboxes() {
        const container = document.getElementById('summary-tag-options');
        if (!container) {
            return;
        }
        container.innerHTML = ''; 
        const sortedTags = [...TAGS].sort(); // Sort tags alphabetically for a better user experience
        sortedTags.forEach(tag => {
            if (tag && tag.trim() !== '') { // Ignore empty or blank tags
                // check all checkboxes initially so the bar chart shows all averages
                container.innerHTML += `<label><input type="checkbox" value="${tag}" checked> ${tag}</label>`;
            }
        });
    }

    // Sets up the custom tag multi-select dropdown behavior.
    function setupTagDropdown() {
        const dropdown = document.getElementById('summary-tag-dropdown');
        const checkboxList = document.getElementById('summary-tag-options');
        if (!dropdown || !checkboxList) {
            return;
        }
        // First, ensure the label element exists. If not, create it. 
        let selectedLabel = dropdown.querySelector('.selected-tags-label');
        if (!selectedLabel) {
            selectedLabel = document.createElement('span');
            selectedLabel.className = 'selected-tags-label';
            selectedLabel.textContent = 'בחר תגיות...'; // Default text
            dropdown.prepend(selectedLabel); // Add it to the beginning of the dropdown div
        }
        // Update label with initially selected tags (all are checked by default)
        updateSelectedTagsLabel();

        // Toggle dropdown visibility when clicking the dropdown (but not the checkbox list)
        dropdown.addEventListener('click', (e) => {
            if (!checkboxList.contains(e.target)) {
                checkboxList.classList.toggle('hidden');
                e.stopPropagation(); // Prevent click from immediately closing the dropdown via document listener
            }
        });

          // When checkboxes change, update the label and rerender the chart
        checkboxList.addEventListener('change', () => {
            updateSelectedTagsLabel();
            const selected = [...checkboxList.querySelectorAll('input:checked')].map(cb => cb.value);
            renderTagsBarChart(selected);
        });

        // Close dropdown if clicking anywhere outside
        document.addEventListener('click', (e) => {
            if (!dropdown.contains(e.target) && !checkboxList.contains(e.target)) {
                checkboxList.classList.add('hidden');
            }
        });

        
         //Updates the text content of the selected tags label.
        function updateSelectedTagsLabel() {
            const selected = [...checkboxList.querySelectorAll('input:checked')].map(cb => cb.value);
            if (selectedLabel) {
                selectedLabel.textContent = selected.length ? selected.join(', ') : 'בחר תגיות...';
            }
        }
    }
    // Attach event listener to the course selection dropdown ---
    const courseSelectElement = document.getElementById("course-select");
    if (courseSelectElement) {
        courseSelectElement.addEventListener("change", (e) => {
            // Need to re-calculate eligible courses because the list might change
            const eligibleCourses = coursesList.filter(course =>
                !course.binaryChecked && course.components && Array.isArray(course.components) && course.components.length > 0
            );
        // Render the component breakdown chart for the selected course
            renderComponentChart(e.target.value, eligibleCourses);
        });
    }
    // Hamburger menu button handler for mobile navigation 
    const hamburgerButton = document.getElementById("hamburger-btn");
    if (hamburgerButton) {
        hamburgerButton.addEventListener("click", () => {
            const navMenu = document.getElementById("nav-menu");
            if (navMenu) navMenu.classList.toggle("active");
        });
    } 

    // START THE APPLICATION
    initializePage();  // This kicks off data fetching and initial UI rendering
});