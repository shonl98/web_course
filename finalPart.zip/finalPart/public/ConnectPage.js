document.addEventListener("DOMContentLoaded", function () {
  // ===== Update Year in Footer =====
  const yearSpan = document.getElementById("year");
  if (yearSpan) {
    yearSpan.textContent = new Date().getFullYear();
  }

  // ===== Login Form Variables =====
  const emailInput = document.getElementById('email');
  const passwordInput = document.getElementById('password');
  const loginBtn = document.querySelector('.login-btn');

  // ===== Hamburger Menu Variables =====
  const hamburgerBtn = document.getElementById("hamburger-btn");
  const navMenu = document.getElementById("nav-menu");

  // ===== Helper Functions =====

  // Removes all existing error bubbles from the page
  function clearErrors() {
    document.querySelectorAll('.input-error-bubble').forEach(el => el.remove());
  }

  // Displays an error bubble next to a specific input element
  function showError(inputEl, message) {
    clearErrors(); // Clear previous errors before showing a new one
    const bubble = document.createElement('div');
    bubble.className = 'input-error-bubble';
    bubble.textContent = message;
    inputEl.after(bubble);
  }

  // Validates email format and length
  function validateEmail(email) {
    if (!email.includes('@')) return "האימייל חייב לכלול @";
    if (email.length < 5) return "אימייל לא תקין"; // A more realistic length
    if (!/^[a-zA-Z0-9@._-]+$/.test(email)) return "האימייל חייב להיות באנגלית בלבד";
    return "";
  }

  // Validates password length
  function validatePassword(password) {
    return password.length >= 6 ? "" : "הסיסמה חייבת לכלול לפחות 6 תווים";
  }

  // Login Button Click Event
  loginBtn?.addEventListener('click', async function (e) {
    e.preventDefault();
    clearErrors();

    let isValid = true;

    // Email validation
    const emailMsg = validateEmail(emailInput.value.trim());
    if (emailMsg) {
      showError(emailInput, emailMsg);
      isValid = false;
    }

    // Password validation
    const passwordMsg = validatePassword(passwordInput.value);
    if (passwordMsg) {
      showError(passwordInput, passwordMsg);
      isValid = false;
    }

    // If validation is ok, send login request to server
    if (isValid) {
      try {
        const res = await fetch('/login', { 
          method: 'POST',
          headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
          body: `email=${encodeURIComponent(emailInput.value)}&password=${encodeURIComponent(passwordInput.value)}`
        });

        const data = await res.json();

        if (data.success) {
          window.location.href = "courses_page.html"; // Redirect to main courses page
        } else {
          showError(passwordInput, data.message || 'שגיאה כללית');
        }
      } catch (error) {
        showError(passwordInput, 'שגיאת תקשורת עם השרת. נסה שוב מאוחר יותר.');
      }
    }
  });

  // ===== Hamburger Menu Logic =====
  hamburgerBtn?.addEventListener("click", function () {
    navMenu.classList.toggle("active");
  });

  document.querySelectorAll("#nav-menu a").forEach(link => {
    link.addEventListener("click", () => {
      navMenu.classList.remove("active");
    });
  });
});