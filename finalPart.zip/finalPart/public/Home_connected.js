// Runs when DOM is fully loaded
document.addEventListener("DOMContentLoaded", () => {

    // Handle back-forward cache
    window.addEventListener('pageshow', function (event) {
        if (event.persisted) {
            location.reload();
        }
    });

    // Fetch courses for connected user
    async function fetchMyCourses() {
        try {
            const response = await fetch('/api/courses');
            // Handle unconnected access
            if (response.status === 401) {
                alert("ההתחברות פגה או שאינך מחובר. אנא התחבר מחדש.");
                window.location.href = '/ConnectPage.html'; // Redirect to login
                return null;
            }
            if (!response.ok) {
                throw new Error(`Server error: ${response.status}`);
            }
            return await response.json();
        } catch (error) {
            console.error('Failed to fetch courses:', error);
            return null;
        }
    }

    // Handle user logout
    document.getElementById('logout').addEventListener('click', function (event) {
        event.preventDefault();
        fetch('/logout', { // Send logout request to server
            method: 'POST', 
            headers: {
                'Content-Type': 'application/json' 
            }
        })
            .then(response => {
                if (response.ok) {
                    window.location.href = 'index.html'; // Redirect after logout
                } else {
                    alert('התנתקות נכשלה. אנא נסה שוב.');
                }
            })
            .catch(error => {
                alert('אירעה שגיאה. אנא נסה שוב מאוחר יותר.');
            });
    });

    // ===== Hamburger Menu Toggle =====
    // Handles opening/closing the mobile navigation menu when hamburger is clicked
    document.getElementById("hamburger-btn")
        ?.addEventListener("click", () => {
            document.getElementById("nav-menu").classList.toggle("active");
        });

    // ===== Update Year in Footer =====
    // Sets the current year dynamically in the footer 
    const yearSpan = document.getElementById("year");
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }

    // Initialize the page
    async function initializePage() {
        const [fetchedCourses] = await Promise.all([
            fetchMyCourses()
        ]);
    }

    initializePage();
});



