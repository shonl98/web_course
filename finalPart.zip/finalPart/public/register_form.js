// Handle student registration form submission
document.getElementById("studentForm").addEventListener("submit", async function (e) {
  e.preventDefault(); // Prevent sending by default
  const password = document.getElementById("password").value;
  const confirmPassword = document.getElementById("confirmPassword").value;
  const termsCheckbox = document.getElementById("terms");
  if (password !== confirmPassword) { // Validate passwart match
    alert("הסיסמאות אינן תואמות.");
    return;
  }
  if (!termsCheckbox.checked) { // Validate terms checkbox
    if (termsCheckbox.disabled) {
      alert("יש לקרוא את תנאי השימוש לפני אישורם.");
    } else {
      alert("יש לאשר את תנאי השימוש ומדיניות הפרטיות.");
    }
    return;
  }
  const email = document.getElementById("email").value;
  const firstName = document.getElementById("firstName").value;
  const lastName = document.getElementById("lastName").value;
  const university = document.getElementById("university").value;
  const major = document.getElementById("major").value;
  const startYear = document.getElementById("startYear").value;
  try { // Send registration request to server
    const res = await fetch('/Register', { 
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `email=${encodeURIComponent(email)}&firstName=${encodeURIComponent(firstName)}&lastName=${encodeURIComponent(lastName)}&password=${encodeURIComponent(password)}&university=${encodeURIComponent(university)}&major=${encodeURIComponent(major)}&startYear=${encodeURIComponent(startYear)}`
    });
    const registrationData = await res.json();
    if (registrationData.success) { // If success, log in automatically
      await loginAndRedirect(email, password);
    } else {
      showErrorMessage(registrationData.message || "אירעה שגיאה בתהליך ההרשמה.");
    }
  } catch (err) {
    showErrorMessage('שגיאת תקשורת עם השרת. אנא נסה שוב מאוחר יותר.');
  }
});

// Attempt login after successful registration, then redirect
async function loginAndRedirect(email, password) {
  try {
    const res = await fetch('/login', {
      method: 'POST',
      headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
      body: `email=${encodeURIComponent(email)}&password=${encodeURIComponent(password)}`
    });
    const loginData = await res.json();
    if (loginData.success) {
      popup(); // Show success popup
    } else {
      showErrorMessage("ההרשמה הצליחה, אך אירעה שגיאה בהתחברות האוטומטית. אנא גש לדף הכניסה והתחבר ידנית.");
    }
  } catch (err) {
    showErrorMessage('שגיאת תקשורת עם השרת במהלך ההתחברות.');
  }
}

// Display error message bubble
function showErrorMessage(message) {
  console.log(message);
  const container = document.getElementById("errorContainer");
  container.innerHTML = ''; 
  container.style.display = "block";
  const bubble = document.createElement("div");
  bubble.className = "input-error-bubble";
  bubble.textContent = message;
  container.appendChild(bubble);
}

// Show popup animation and redirect to homepage
function popup() {
  document.getElementById("popup").classList.remove("hidden");
  const lottie = document.getElementById("lottie");
  const totalFrames = 94;
  const frameRate = 60;
  const durationInMs = (totalFrames / frameRate) * 3000;
  lottie.stop();
  lottie.play();
  setTimeout(() => {
    document.getElementById("popup").style.display = "none";
    window.location.href = "Home_connected.html";
  }, durationInMs);
}

const modal = document.getElementById("termsModal");
const openLink = document.getElementById("openTerms");
const termsText = document.getElementById("termsText");
const termsCheckbox = document.getElementById("terms");

// Show modal with terms of use text loaded from file & enable checkbox if successful
openLink.addEventListener("click", function (e) {
  e.preventDefault();
  modal.classList.remove("hidden");
  fetch("./txt/terms_of_use.txt")
    .then((response) => {
      if (!response.ok) throw new Error("שגיאה בטעינת תנאי השימוש.");
      return response.text();
    })
    .then((text) => {
      termsText.textContent = text;
      termsCheckbox.disabled = false;
    })
    .catch((error) => {
      termsText.textContent = "אירעה שגיאה בטעינת תנאי השימוש.";
      console.error("שגיאה:", error);
    });
});

// Close popup
function closeModal() {
  modal.classList.add("hidden");
}
// Load "option" elements from a text file and insert them into a "select" by ID
function loadOptionsFromFile(fileName, selectId) {
  fetch(fileName)
    .then((response) => response.text())
    .then((data) => {
      const lines = data
        .split(/[\r\n]+/)
        .map((line) => line.trim())
        .filter((line) => line);
      const select = document.getElementById(selectId);
      lines.forEach((line) => {
        const option = document.createElement("option");
        option.value = line;
        option.textContent = line;
        select.appendChild(option);
      });
    })
    .catch((error) => {
      console.error(`שגיאה בטעינת ${fileName}:`, error);
    });
}

document.getElementById("year").textContent = new Date().getFullYear(); 
loadOptionsFromFile("./txt/study_topics.txt", "major");
loadOptionsFromFile("./txt/academic_institutions.txt", "university");