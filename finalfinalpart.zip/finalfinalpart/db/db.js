import mysql from 'mysql2';
import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import dbConfig from './db.config.js';
import { error } from 'console';

// Create a connection to the database
const db = mysql.createConnection({
    host: dbConfig.host,
    user: dbConfig.user,
    password: dbConfig.password,
    database: dbConfig.database,
    charset: 'utf8mb4' // Supports special characters and languages like Hebrew
});



// ==========================================================
// Part 1: Seeding functions for base data from files
// ==========================================================

// Generic function to read a text file (one item per line) and insert into a table.
// Uses 'INSERT IGNORE' to prevent errors for duplicate entries.
function seedTableFromFile(filePath, tableName, onComplete) {
    const columnName = (tableName === 'tags') ? 'tag' : 'name';
    const __dirname = path.dirname(fileURLToPath(import.meta.url));
    const fullPath = path.join(__dirname, filePath);

    fs.readFile(fullPath, 'utf8', (err, data) => {
        if (err) return onComplete(err);
        const items = data.split('\n').map(line => line.trim()).filter(Boolean);
        if (items.length === 0) return onComplete();
        
        let queriesFinished = 0;
        const sql = `INSERT IGNORE INTO ${tableName} (${columnName}) VALUES (?)`;
        items.forEach(item => {
            db.query(sql, [item], () => {
                queriesFinished++;
                if (queriesFinished === items.length) onComplete();
            });
        });
    });
}

// Seeds academic institutions from a file.
function seedInstitutions(onComplete) {
    console.log('Seeding institutions...');
    seedTableFromFile('../public/txt/academic_institutions.txt', 'institutions', onComplete);
}

// Seeds study programs from a file.
function seedPrograms(onComplete) {
    console.log('Seeding programs...');
    seedTableFromFile('../public/txt/study_topics.txt', 'programs', onComplete);
}

// Seeds a predefined list of base tags.
function seedBaseTags(onComplete) {
    console.log('Seeding base tags...');
    const tags = ['מתמטיקה', 'מדעי המחשב', 'פיזיקה', 'כימיה', 'ביולוגיה'];
    let queriesFinished = 0;
    tags.forEach(tag => {
        db.query('INSERT IGNORE INTO tags (tag) VALUES (?)', [tag], () => {
            queriesFinished++;
            if (queriesFinished === tags.length) onComplete();
        });
    });
}

// Seeds a predefined list of grade component types.
function seedBaseComponents(onComplete) {
    console.log('Seeding base grade components...');
    const components = ['Final Exam', 'Midterm Exam', 'Homework', 'Project', 'Lab', 'Presentation', 'Attendance'];
    let queriesFinished = 0;
    components.forEach(comp => {
        db.query('INSERT IGNORE INTO grade_components (component) VALUES (?)', [comp], () => {
            queriesFinished++;
            if (queriesFinished === components.length) onComplete();
        });
    });
}

// ==========================================================
// Part 2: Seeding functions for Lookup Tables + Test Data
// ==========================================================

// Populates the lookup tables for semesters and academic years.
function seedSemestersAndYears(onComplete) {
    console.log('Seeding semesters and years...');
    const semesters = ['חורף', 'אביב', 'קיץ'];
    const years = ['א', 'ב', 'ג', 'ד'];

    let queriesFinished = 0;
    const totalQueries = semesters.length + years.length;
    const checkComplete = () => {
        queriesFinished++;
        if (queriesFinished === totalQueries) onComplete();
    };

    semesters.forEach(semester => {
        db.query('INSERT IGNORE INTO semesters (name) VALUES (?)', [semester], checkComplete);
    });

    years.forEach(year => {
        db.query('INSERT IGNORE INTO years (name) VALUES (?)', [year], checkComplete);
    });
}

// Test data representing a set of courses for a sample user.
const newCoursesData = [
    {
        id: "c1",
        name: "מבוא למדעי המחשב",
        credits: 4,
        grade: 95,
        year: "א",
        semester: "חורף",
        tags: ["מדעי המחשב", "מתמטיקה"],
        components: [
            { type: "מבחן", weight: 70, grade: 96 },
            { type: "עבודה", weight: 30, grade: 92 },
        ],
        binaryChecked: false,
        bonus: 2,
        real_grade: 97,
    },
    {
        id: "c2",
        name: "כתיבה אקדמית באנגלית",
        credits: 2,
        grade: 85,
        year: "א",
        semester: "אביב",
        tags: ["אנגלית", "רב מלל"],
        components: [],
        binaryChecked: true,
        bonus: 1,
        real_grade: 86,
    },
    {
        id: "c3",
        name: "פסיכולוגיה קוגניטיבית",
        credits: 3,
        grade: 88,
        year: "ב",
        semester: "קיץ",
        tags: ["פסיכולוגיה"],
        components: [
            { type: "מבחן", weight: 60, grade: 85 },
            { type: "תרגיל", weight: 40, grade: 92 },
        ],
        binaryChecked: false,
        bonus: 0,
        real_grade: 87,
    },
    {
        id: "c4",
        name: "סטטיסטיקה למדעי החברה",
        credits: 3,
        grade: 76,
        year: "ג",
        semester: "חורף",
        tags: ["מתמטיקה", "פסיכולוגיה"],
        components: [],
        binaryChecked: true,
        bonus: 0,
        real_grade: 76,
    },
    {
        id: "c5",
        name: "פרויקטים במדעי המחשב",
        credits: 5,
        grade: 90,
        year: "ד",
        semester: "אביב",
        tags: ["מדעי המחשב"],
        components: [{ type: "פרויקט", weight: 100, grade: 90 }],
        binaryChecked: false,
        bonus: 2,
        real_grade: 92,
    },
    {
        id: "c6",
        name: "תרבות אנגלית",
        credits: 2,
        grade: 82,
        year: "ב",
        semester: "חורף",
        tags: ["אנגלית"],
        components: [],
        binaryChecked: true,
        bonus: 0,
        real_grade: 82,
    },
    {
        id: "c7",
        name: "יסודות בלוגיקה",
        credits: 3,
        grade: 89,
        year: "א",
        semester: "קיץ",
        tags: ["מתמטיקה"],
        components: [
            { type: "בוחן", weight: 30, grade: 90 },
            { type: "מבחן", weight: 70, grade: 88 },
        ],
        binaryChecked: false,
        bonus: 1,
        real_grade: 90,
    },
    {
        id: "c8",
        name: "מבוא לפסיכולוגיה",
        credits: 3,
        grade: 77,
        year: "ג",
        semester: "אביב",
        tags: ["פסיכולוגיה", "רב מלל"],
        components: [],
        binaryChecked: true,
        bonus: 0,
        real_grade: 77,
    },
    {
        id: "c9",
        name: "מערכות הפעלה",
        credits: 4,
        grade: 91,
        year: "ג",
        semester: "קיץ",
        tags: ["מדעי המחשב"],
        components: [
            { type: "מבחן", weight: 80, grade: 92 },
            { type: "תרגיל", weight: 20, grade: 85 },
        ],
        binaryChecked: false,
        bonus: 0,
        real_grade: 91.4,
    }
];

// Creates a default test user if one doesn't exist.
// NOTE: Passwords should be hashed in a production environment.
function seedTestUser(onComplete) {
    console.log("Seeding test user...");
    const testUser = {
        email: 'test@example.com',
        first_name: 'ישראל',
        last_name: 'ישראלי',
        password: 'password123',
        institution_name: 'אוניברסיטת תל אביב',
        program_name: 'מדעי המחשב',
        start_year: 2022
    };
    const sql = `INSERT INTO users (email, first_name, last_name, password, institution_name, program_name, start_year) VALUES (?, ?, ?, ?, ?, ?, ?) ON DUPLICATE KEY UPDATE first_name=VALUES(first_name)`;
    const params = [testUser.email, testUser.first_name, testUser.last_name, testUser.password, testUser.institution_name, testUser.program_name, testUser.start_year];
    db.query(sql, params, (err) => onComplete(err, testUser.email));
}

// Seeds the test courses for a given user, linking them to existing semesters and years.
function seedTestCourses(userEmail, onComplete) {
    console.log("Seeding test courses...");
    let queriesFinished = 0;
    const insertedCourseIds = [];

    const getLookupId = (tableName, name, callback) => {
        db.query(`SELECT id FROM ${tableName} WHERE name = ?`, [name], (err, results) => {
            if (err) return callback(err);
            if (results.length === 0) return callback(`Could not find ${tableName} with name: ${name}`);
            callback(null, results[0].id);
        });
    };

    newCoursesData.forEach(course => {
        Promise.all([
            new Promise((resolve, reject) => getLookupId('semesters', course.semester, (err, id) => err ? reject(err) : resolve(id))),
            new Promise((resolve, reject) => getLookupId('years', course.year, (err, id) => err ? reject(err) : resolve(id)))
        ])
            .then(([semesterId, yearId]) => {
                const sql = `INSERT INTO courses (course_name, credits, semester_id, year_id, grade, real_grade, bonus, is_binary, user_email) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)`;
                const params = [course.name, course.credits, semesterId, yearId, course.grade, course.real_grade, course.bonus, course.binaryChecked, userEmail];

                db.query(sql, params, (err, results) => {
                    if (err) {
                        console.error("Error inserting course:", course.name, err);
                    } else {
                        insertedCourseIds.push(results.insertId);
                    }
                    
                    queriesFinished++;
                    if (queriesFinished === newCoursesData.length) {
                        onComplete(null, insertedCourseIds);
                    }
                });
            })
            .catch(err => {
                console.error("Error in Promise.all:", err);
                queriesFinished++;
                if (queriesFinished === newCoursesData.length) {
                    onComplete(null, insertedCourseIds);
                }
            });
    });
}

// Creates the links between courses and their associated tags and grade components.
function seedCourseLinks(courseIds, onComplete) {
    console.log("Seeding course links (tags and components)...");
    if (!courseIds || courseIds.length === 0) return onComplete();

    let totalLinks = 0;
    let linksFinished = 0;

    const onLinkDone = () => {
        linksFinished++;
        if (linksFinished === totalLinks) onComplete();
    };

    courseIds.forEach((courseId, index) => {
        const course = newCoursesData[index];

        if (course.tags && course.tags.length > 0) {
            course.tags.forEach(tag => {
                totalLinks++;
                db.query('INSERT IGNORE INTO course_tags (course_id, tag) VALUES (?, ?)', [courseId, tag], onLinkDone);
            });
        }

        if (course.components && course.components.length > 0) {
            course.components.forEach(componentData => {
                totalLinks++;
                db.query('INSERT IGNORE INTO grade_components (component) VALUES (?)', [componentData.type], (err, res) => {
                    if (err) {
                        console.error("Error inserting grade component:", err);
                        return onLinkDone(); // Still need to count this to finish
                    }
                    db.query('SELECT id FROM grade_components WHERE component = ?', [componentData.type], (err, res) => {
                        if (err || res.length === 0) {
                            console.error("Grade component not found:", componentData.type);
                            return onLinkDone(); // Still need to count this to finish
                        }
                        const componentId = res[0].id;
                        const sql = 'INSERT IGNORE INTO course_grade_components (course_id, component, weight, grade) VALUES (?, ?, ?, ?)';
                        db.query(sql, [courseId, componentId, componentData.weight, componentData.grade], onLinkDone);
                    });
                });
            });
        }
    });

    if (totalLinks === 0) onComplete();
}
// ==========================================================
// Part 3: Main function to orchestrate and run all seeding tasks
// ==========================================================

function runAllSeeding() {
    console.log('--- Connecting to DB and starting all seeding tasks ---');
    db.connect((err) => {
        if (err) {
            console.error('FATAL: Could not connect to the database.', err);
            return process.exit(1);
        }
        console.log('Database connected successfully.');

        // check if seeding been done already - if yes - return : else seed the tables
        db.query('SELECT COUNT(*) as userCount FROM users', (queryErr, results) => {
            if (queryErr && queryErr.code !== 'ER_NO_SUCH_TABLE') {
                console.error('Error querying users table:', queryErr);
                return;
            }

            if (results && results[0].userCount > 0) {
                console.log('Users table already contains data. Skipping seeding process.');
                return; 
            }

            console.log('Users table is empty or non-existent. Starting seeding process...');
            
            seedInstitutions(err => {
                if (err) return console.error('Seeding failed at: Institutions', err);
                console.log('Finished seeding institutions.');

                seedPrograms(err => {
                    if (err) return console.error('Seeding failed at: Programs', err);
                    console.log('Finished seeding programs.');

                    seedBaseTags(err => {
                        if (err) return console.error('Seeding failed at: Base Tags', err);
                        console.log('Finished seeding base tags.');

                        seedBaseComponents(err => {
                            if (err) return console.error('Seeding failed at: Base Components', err);
                            console.log('Finished seeding base components.');

                            seedSemestersAndYears(err => {
                                if (err) return console.error('Seeding failed at: Semesters and Years', err);
                                console.log('Finished seeding semesters and years.');

                                console.log('\n--- Seeding TEST data ---');
                                seedTestUser((err, userEmail) => {
                                    if (err) return console.error('Seeding failed at: Test User', err);
                                    console.log(`Finished seeding test user: ${userEmail}`);

                                    seedTestCourses(userEmail, (err, courseIds) => {
                                        if (err) return console.error('Seeding failed at: Test Courses', err);
                                        console.log(`Finished seeding test courses. IDs: [${courseIds.join(', ')}]`);

                                        seedCourseLinks(courseIds, (err) => {
                                            if (err) return console.error('Seeding failed at: Course Links', err);
                                            console.log('Finished seeding course links.');

                                            console.log('\n--- ALL SEEDING TASKS ARE COMPLETE ---');
                                        });
                                    });
                                });
                            });
                        });
                    });
                });
            });
        });
    });
}


// ------------------------------------
// Execute the seeding process
// ------------------------------------
runAllSeeding();

export default db;
