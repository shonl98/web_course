export default {
    host: 'localhost',
    user: 'root',
    password: '123456',
    database: 'academic_records',
};

