import db from '../db/db.js';

// Get  data course by its ID
const getCourseById = (id) => {
    return new Promise((resolve, reject) => {
        const sql = `
            SELECT
                c.id, c.course_name AS name, c.credits, s.name AS semester, y.name AS year,
                c.grade, 
                c.real_grade,
                c.bonus, c.is_binary AS binaryChecked,
                GROUP_CONCAT(DISTINCT t.tag) AS tags,
                GROUP_CONCAT(DISTINCT CONCAT(g.component, ':', cgc.weight, ':', cgc.grade) SEPARATOR ';') AS components
            FROM courses c
            LEFT JOIN course_tags ct ON c.id = ct.course_id
            LEFT JOIN tags t ON ct.tag = t.tag
            LEFT JOIN course_grade_components cgc ON c.id = cgc.course_id
            LEFT JOIN grade_components g ON cgc.component = g.id
            LEFT JOIN semesters s ON c.semester_id = s.id
            LEFT JOIN years y ON c.year_id = y.id
            WHERE c.id = ?
            GROUP BY c.id;
        `;

        db.query(sql, [id], (err, results) => {
            if (err) return reject(err); // Handle DB error
            if (results.length === 0) return resolve(null); // No course found
            const course = results[0];
            course.tags = course.tags ? course.tags.split(',') : []; // Convert comma-separated tags string to array
            course.components = course.components ? course.components.split(';').map(compStr => { // Convert components string to map
                const [component, weight, grade] = compStr.split(':');
                return { component, weight: parseFloat(weight), grade: parseFloat(grade) };
            }) : [];
            course.binaryChecked = Boolean(course.binaryChecked);
            resolve(course);
        });
    });
};

// Get all courses for the authenticated user
export const getCoursesForAuthenticatedUser = (req, res) => {
    const userEmail = req.userEmail;
    const sql = `
        SELECT
            c.id, c.course_name AS name, c.credits, s.name AS semester, y.name AS year,
            c.grade,
            c.real_grade,
            c.bonus, c.is_binary AS binaryChecked,
            GROUP_CONCAT(DISTINCT t.tag) AS tags,
            GROUP_CONCAT(DISTINCT CONCAT(g.component, ':', cgc.weight, ':', cgc.grade) SEPARATOR ';') AS components
        FROM courses c
        LEFT JOIN course_tags ct ON c.id = ct.course_id
        LEFT JOIN tags t ON ct.tag = t.tag
        LEFT JOIN course_grade_components cgc ON c.id = cgc.course_id
        LEFT JOIN grade_components g ON cgc.component = g.id
        LEFT JOIN semesters s ON c.semester_id = s.id
        LEFT JOIN years y ON c.year_id = y.id
        WHERE c.user_email = ?
        GROUP BY c.id
        ORDER BY y.name, s.name;
    `;

    db.query(sql, [userEmail], (err, courses) => {
        if (err) {
            return res.status(500).json({ error: 'Database error' });
        }
        courses.forEach(course => {
            course.tags = course.tags ? course.tags.split(',') : []; // Convert comma-separated tags string to array
            course.components = course.components ? course.components.split(';').map(compStr => { // Convert components string to map
                const [component, weight, grade] = compStr.split(':');
                return { component: component, weight: parseFloat(weight), grade: parseFloat(grade) };
            }) : [];
            course.binaryChecked = Boolean(course.binaryChecked);
        });
        res.json(courses);
    });
};

// Create a new course for the authenticated user
export const createCourseForAuthenticatedUser = async (req, res) => {
    const { name, credits, semester, year, grade, real_grade, bonus, binaryChecked, tags, components } = req.body;
    const userEmail = req.userEmail;
    const is_binary = binaryChecked;

    db.beginTransaction(async (err) => {
        if (err) return res.status(500).json({ error: 'Database error starting transaction' });
        try { // Insert main course record
            const sqlInsertCourse = `
                INSERT INTO courses (course_name, credits, semester_id, year_id, grade, real_grade, bonus, is_binary, user_email)
                VALUES (?, ?, (SELECT id FROM semesters WHERE name = ?), (SELECT id FROM years WHERE name = ?), ?, ?, ?, ?, ?)
            `;
            const courseResult = await new Promise((resolve, reject) => {
                db.query(sqlInsertCourse, [name, credits, semester, year, grade, real_grade, bonus, is_binary, userEmail], (err, result) => err ? reject(err) : resolve(result));
            });
            const courseId = courseResult.insertId;
            if (tags && tags.length > 0) { // Insert course tags
                const tagsPromises = tags.map(tag => new Promise((resolve, reject) => {
                    db.query(`INSERT INTO course_tags (course_id, tag) VALUES (?, ?)`, [courseId, tag], (err) => err ? reject(err) : resolve());
                }));
                await Promise.all(tagsPromises);
            }
            if (components && components.length > 0) { // Insert grade components
                const componentsPromises = components.map(comp => new Promise((resolve, reject) => {
                    const sqlInsertComponent = `
                        INSERT INTO course_grade_components (course_id, component, weight, grade)
                        VALUES (?, (SELECT id FROM grade_components WHERE component = ?), ?, ?)
                    `;
                    db.query(sqlInsertComponent, [courseId, comp.component, comp.weight, comp.grade], (err) => err ? reject(err) : resolve());
                }));
                await Promise.all(componentsPromises);
            }
            const newCourse = await getCourseById(courseId); // Return the full course data
            db.commit((err) => {
                if (err) throw err;
                res.status(201).json(newCourse);
            });

        } catch (error) {
            console.error('Error during course creation:', error);
            db.rollback(() => res.status(500).json({ error: 'Database error during course creation' }));
        }
    });
};

// Update an existing course for the authenticated user
export const updateCourseForAuthenticatedUser = async (req, res) => {
    const courseId = req.params.id;
    const userEmail = req.userEmail;
    const { name, credits, semester, year, grade, real_grade, bonus, binaryChecked, tags, components } = req.body;
    const is_binary = binaryChecked;
    db.beginTransaction(async (err) => {
        if (err) return res.status(500).json({ error: 'Database error starting transaction' });
        try { // Update main course fields
            const sqlUpdateCourse = `
                UPDATE courses SET 
                    course_name = ?, credits = ?, 
                    semester_id = (SELECT id FROM semesters WHERE name = ?),
                    year_id = (SELECT id FROM years WHERE name = ?), 
                    grade = ?, real_grade = ?, bonus = ?, is_binary = ?
                WHERE id = ? AND user_email = ?`;
            const params = [name, credits, semester, year, grade, real_grade, bonus, is_binary, courseId, userEmail];
            const updateResult = await new Promise((resolve, reject) => {
                db.query(sqlUpdateCourse, params, (err, result) => err ? reject(err) : resolve(result));
            });
            if (updateResult.affectedRows === 0) { // Check if course was found and updated
                return db.rollback(() => res.status(404).json({ error: 'Course not found or you do not have permission to edit it.' }));
            }
            await Promise.all([ // Remove existing tags and components
                new Promise((resolve, reject) => db.query(`DELETE FROM course_tags WHERE course_id = ?`, [courseId], (err) => err ? reject(err) : resolve())),
                new Promise((resolve, reject) => db.query(`DELETE FROM course_grade_components WHERE course_id = ?`, [courseId], (err) => err ? reject(err) : resolve()))
            ]);
            if (tags && tags.length > 0) { // Re-insert updated tags
                await Promise.all(tags.map(tag => new Promise((resolve, reject) => {
                    db.query(`INSERT INTO course_tags (course_id, tag) VALUES (?, ?)`, [courseId, tag], (err) => err ? reject(err) : resolve());
                })));
            }
            if (components && components.length > 0) { // Re-insert updated grade components
                await Promise.all(components.map(comp => new Promise((resolve, reject) => {
                    const sqlInsertComponent = `
                        INSERT INTO course_grade_components (course_id, component, weight, grade)
                        VALUES (?, (SELECT id FROM grade_components WHERE component = ?), ?, ?)`;
                    db.query(sqlInsertComponent, [courseId, comp.component, comp.weight, comp.grade], (err) => err ? reject(err) : resolve());
                })));
            }
            const updatedCourse = await getCourseById(courseId); // Fetch and return the updated course
            db.commit((err) => {
                if (err) throw err;
                res.json(updatedCourse);
            });
        } catch (error) {
            console.error('Error during course update:', error);
            db.rollback(() => res.status(500).json({ error: 'Database error during course update' }));
        }
    });
};

// Delete a course by ID for the authenticated user
export const deleteCourseForAuthenticatedUser = async (req, res) => {
    const courseId = req.params.id;
    const userEmail = req.userEmail;
    try { // Delete course only if it belongs to the user
        const result = await new Promise((resolve, reject) => {
            const sql = 'DELETE FROM courses WHERE id = ? AND user_email = ?';
            db.query(sql, [courseId, userEmail], (err, result) => err ? reject(err) : resolve(result));
        });
        if (result.affectedRows === 0) {
            return res.status(404).json({ error: 'Course not found or you do not have permission to delete it.' });
        }

        res.status(204).send();
    } catch (error) {
        console.error('Error during course deletion:', error);
        res.status(500).json({ error: 'Database error' });
    }
};