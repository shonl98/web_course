import express from 'express';
import {
    getCoursesForAuthenticatedUser,
    createCourseForAuthenticatedUser,
    updateCourseForAuthenticatedUser,
    deleteCourseForAuthenticatedUser
} from '../controllers/coursesController.js';

const router = express.Router();

// Course routes for CRUD operations
router.get('/', getCoursesForAuthenticatedUser);
router.post('/', createCourseForAuthenticatedUser);
router.put('/:id', updateCourseForAuthenticatedUser);
router.delete('/:id', deleteCourseForAuthenticatedUser);

export default router;