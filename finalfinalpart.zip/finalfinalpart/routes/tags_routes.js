import express from 'express';
import db from '../db/db.js';

const router = express.Router();

// Returns all available tags from the database as an array
router.get('/', (req, res) => {
    db.query('SELECT tag FROM tags', (err, results) => {
        if (err) {
            console.error('DB error:', err);
            return res.status(500).json({ success: false, message: 'DB error' });
        }
        const tags = results.map(row => row.tag);
        res.json({ success: true, tags });
    });
});

export default router;