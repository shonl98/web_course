import express from 'express';
import db from '../db/db.js';

// Insert new user to database
const Register = (req, res) => {
    const { email, firstName, lastName, password, university, major, startYear } = req.body;
    const sql = `INSERT INTO users (email, first_name, last_name, password, institution_name, program_name, start_year)
    VALUES (?, ?, ?, ?, ?, ?, ?)`;
    db.query(sql, [email, firstName, lastName, password, university || null, major || null, startYear || null], (err, result) => {
        if (err) {
            console.error(err);
           if (err.code === 'ER_DUP_ENTRY') {
            return res.json({ success: false, message: 'כתובת מייל זו כבר רשומה במערכת' });
            }
            else {
                return res.json({ success: false, message: 'שגיאה בשרת' });
            }
        }
        else {
            return res.json({ success: true });
        }
    });
};

const router = express.Router();
router.post('/', Register);
export default router;
