import express from 'express';
import db from '../db/db.js';

// Handle user login
const login = (req, res) => {
  const { email, password } = req.body;
  db.query('SELECT * FROM users WHERE email = ?', [email], (err, results) => {
    if (err) {
      console.error("שגיאה במסד הנתונים:", err);
      return res.status(500).json({ success: false, message: "שגיאת שרת" });
    }
    // If mail not exsits in the DB
    if (results.length === 0) {
      return res.status(401).json({ success: false, message: "פרטי התחברות שגויים" });
    }
    const user = results[0];
    // If passward match
    if (user.password === password) {
      res.cookie('userAuth', user.email, { // Create cookie
        maxAge: 7 * 24 * 60 * 60 * 1000, // Life time
        httpOnly: true,  
        secure: process.env.NODE_ENV === 'production', 
        sameSite: 'Strict' 
      });
      return res.json({ success: true, redirect: '/courses_page.html' });
    } else {
      return res.status(401).json({ success: false, message: "פרטי התחברות שגויים" });
    }
  });
};

const router = express.Router();
router.post('/', login);
export default router;
