// Runs when DOM is fully loaded
document.addEventListener("DOMContentLoaded", () => {
    var coursesList = [];
    var isEditMode = false;

    const tbody = document.getElementById("grades-body");
    const toggleBtn = document.getElementById("toggle-edit");
    const yearFilter = document.getElementById("yearFilter");
    const semesterFilter = document.getElementById("semesterFilter");
    const hamburgerBtn = document.getElementById("hamburger-btn");
    const navMenu = document.getElementById("nav-menu");

    // Handle back-forward cache
    window.addEventListener('pageshow', function (event) {
        if (event.persisted) {
            location.reload();
        }
    });  

    // Fetch courses for connected user
    async function fetchMyCourses() {
        try {
            const response = await fetch('/api/courses');
            // Handle unconnected access
            if (response.status === 401) {
                alert("ההתחברות פגה או שאינך מחובר. אנא התחבר מחדש.");
                window.location.href = '/ConnectPage.html'; // Redirect to login
                return null;
            }
            if (!response.ok) throw new Error(`Server error fetching courses: ${response.status}`);
            return await response.json();
        } catch (error) {
            console.error('Failed to fetch courses:', error);
            if (tbody) tbody.innerHTML = '<tr><td colspan="3">שגיאה בטעינת הקורסים.</td></tr>';
            return null;
        }
    }
    
    // get user details 
    async function fetchUserDetails() {
        try {
            const response = await fetch('/api/user-details');
            if (response.status === 401) {
                console.warn("User not authenticated while fetching details.");
                return null;
            }
            if (!response.ok) throw new Error(`Server error fetching user details: ${response.status}`);
            return await response.json();
        } catch (error) {
            console.error('Failed to fetch user details:', error);
            return null;
        }
    }

    // Initialize the page
    async function initializePage() {
        const [fetchedCourses, userDetails] = await Promise.all([
            fetchMyCourses(),
            fetchUserDetails()
        ]);

        updateUserDetails(userDetails);

        if (fetchedCourses === null) {
            console.error("Page initialization halted: could not fetch courses.");
            return;
        }

        coursesList = fetchedCourses;
        applyFilters();

        const yearSpan = document.getElementById("year");
        if (yearSpan) yearSpan.textContent = new Date().getFullYear();
    }

    // Handle user logout
    document.getElementById('logout').addEventListener('click', function (event) {
        event.preventDefault();
        fetch('/logout', { // Send logout request to server
            method: 'POST', 
            headers: {
                'Content-Type': 'application/json' 
            }
        })
            .then(response => {
                if (response.ok) {
                    window.location.href = 'index.html'; // Redirect after logout
                } else {
                    alert('התנתקות נכשלה. אנא נסה שוב.');
                }
            })
            .catch(error => {
                alert('אירעה שגיאה. אנא נסה שוב מאוחר יותר.');
            });
    });

    function updateUserDetails(details) {
        const defaultText = '--';
        document.getElementById('fname').textContent = details?.first_name ?? defaultText;
        document.getElementById('lname').textContent = details?.last_name ?? defaultText;
        document.getElementById('inst').textContent = details?.institution_name ?? defaultText;
        document.getElementById('dept').textContent = details?.program_name ?? defaultText;
        document.getElementById('start').textContent = details?.start_year ?? defaultText;
    }

    function escapeHTML(str) {
        if (typeof str !== 'string') str = String(str);
        return str
            .replace(/&/g, "&")
            .replace(/</g, "<")
            .replace(/>/g, ">")
            .replace(/"/g, "")
            .replace(/'/g, "'");
    }

    // Render the table with courses in view or edit mode
    function renderTable(courseList, editMode = false) {
        if (!tbody) {
            console.error("Cannot render table: tbody element not found.");
            return;
        }

        tbody.parentElement.classList.toggle("edit-mode", editMode);
        tbody.innerHTML = "";
        let creditsSum = 0;
        let totalCreditsForAvg = 0;
        let weightedSum = 0;

        if (courseList.length === 0) {
            tbody.innerHTML = '<tr><td colspan="3" style="text-align: center;">אין קורסים להצגה.</td></tr>';
        } else {
            courseList.forEach((course) => {
                const row = document.createElement("tr");
                row.dataset.id = course.id;

                const credits = parseFloat(course.credits) || 0;
                const real_grade = parseFloat(course.real_grade);
                const gradeDisplay = course.binaryChecked ? "עובר" : (isNaN(real_grade) ? "--" : real_grade.toFixed(1)); // If binary, display over

                row.innerHTML = `
                  <td><input type="text" value="${escapeHTML(course.name)}" ${editMode ? "" : "readonly"} /></td>
                  <td><input type="number" value="${credits}" ${editMode ? "" : "readonly"} /></td>
                  <td><input type="text" value="${escapeHTML(gradeDisplay)}" ${editMode ? "" : "readonly"} /></td>
                `;
                tbody.appendChild(row);

                if (!isNaN(credits) && credits > 0) {
                    creditsSum += credits; // Include all credits
                    // Calc only non-binari
                    if (!course.binaryChecked && !isNaN(real_grade)) {
                        // If non-binari - included in avg
                        totalCreditsForAvg += credits;
                        weightedSum += real_grade * credits;
                    }
                }
            });
        }
        
        // Update total and avg display
        document.getElementById("total-credits").textContent = creditsSum.toFixed(1);
        document.getElementById("weighted-average").textContent =
            totalCreditsForAvg > 0 ? (weightedSum / totalCreditsForAvg).toFixed(2) : "--";
    }

    // Filter the course based on year & semester
    function applyFilters() {
        const selectedYear = yearFilter?.value || "הכל";
        const selectedSemester = semesterFilter?.value || "הכל";

        const filtered = coursesList.filter((course) => {
            const matchYear = selectedYear === "הכל" || String(course.year) === selectedYear;
            const matchSemester = selectedSemester === "הכל" || String(course.semester) === selectedSemester;
            return matchYear && matchSemester;
        });

        renderTable(filtered, isEditMode);
    }

    // Update course objects in memory based on values entered in the summary table
    function updateCoursesFromTable() {
        if (!tbody) return;

        const rows = tbody.querySelectorAll("tr");
        rows.forEach(row => {
            const courseId = row.dataset.id;
            if (!courseId) return;

            const course = coursesList.find(c => String(c.id) === courseId);

            if (course) {
                const inputs = row.querySelectorAll("input");
                // Update the course object in the array
                course.name = inputs[0].value;
                course.credits = parseFloat(inputs[1].value) || 0;

                const gradeInput = inputs[2].value;
                // Update grade and binary status based on input
                const numericGrade = parseFloat(gradeInput);

                if (isNaN(numericGrade) || gradeInput.trim().toLowerCase() === 'עובר') {
                    course.binaryChecked = true;
                    course.real_grade = null;
                } else {
                    course.binaryChecked = false;
                    course.real_grade = numericGrade;
                }
            }
        });
    }

    // Toggle between edit and view mode for the grade table
    if (toggleBtn) {
        toggleBtn.addEventListener("click", () => {
            if (isEditMode) {
                updateCoursesFromTable();
                alert("שימו לב: השינויים שביצעתם עודכנו בתצוגה הנוכחית. הם ויזואליים בלבד ולא נשמרים בשרת. הנתונים המקוריים יופיעו ברענון העמוד.");
            }

            isEditMode = !isEditMode;
            toggleBtn.textContent = isEditMode ? "שמור תעודה" : "ערוך תעודה";
            applyFilters(); // Re-render the table with the (potentially updated) data
        });
    }

    // Update table on filter change
    if (yearFilter) yearFilter.addEventListener("change", applyFilters);
    if (semesterFilter) semesterFilter.addEventListener("change", applyFilters);

    if (hamburgerBtn && navMenu) {
        hamburgerBtn.addEventListener("click", () => {
            navMenu.classList.toggle("active");
        });
    }

    initializePage();
});