// Runs when DOM is fully loaded
document.addEventListener("DOMContentLoaded", () => {
    var coursesList = [];
    var TAGS = [];
    var currentEditingCard = null; // A reference to the course card being edited

    // Handle back-forward cache
    window.addEventListener('pageshow', function (event) {
        if (event.persisted) {
            location.reload();
        }
    });

    // Fetch courses for connected user
    async function fetchMyCourses() {
        try {
            const response = await fetch('/api/courses');
            // Handle unconnected access
            if (response.status === 401) {
                alert("ההתחברות פגה או שאינך מחובר. אנא התחבר מחדש.");
                window.location.href = '/ConnectPage.html'; // Redirect to login
                return null;
            }
            if (!response.ok) {
                throw new Error(`Server error: ${response.status}`);
            }
            return await response.json();
        } catch (error) {
            console.error('Failed to fetch courses:', error);
            return null;
        }
    }

    // Fetch available tags from server
    async function fetchTags() {
        try {
            const res = await fetch("/api/tags");
            if (!res.ok) throw new Error(`Server error fetching tags: ${res.status}`); // Handle server error
            const data = await res.json();
            return data && Array.isArray(data.tags) ? data.tags : []; // Tranform the answer to tags array
        } catch (error) {
            console.error("Network error fetching tags: " + e.message);
            return [];
        }
    }

    // Add new course to server
    async function addCourse(course) {
        try {
            const url = '/api/courses';
            const response = await fetch(url, {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(course)
            });
            if (!response.ok) throw new Error(`Server error: ${response.status}`); // Handle server error
            return await response.json();
        } catch (error) {
            console.error('Failed to add course:', error);
            return null;
        }
    }

    // Update existing course by ID
    async function updateCourse(courseId, course) {
        console.log("2. [לקוח] שולח את האובייקט הבא לשרת לעדכון:", course);
        try {
            const url = `/api/courses/${courseId}`;
            const response = await fetch(url, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(course)
            });
            if (!response.ok) throw new Error(`Server error: ${response.status}`); // Handle server error
            const updatedCourse = await response.json();
            return updatedCourse;
        } catch (error) {
            return null;
        }
    }

    // Delete existing course by ID
    async function deleteCourse(courseId) {
        try {
            const url = `/api/courses/${courseId}`;
            const response = await fetch(url, { method: 'DELETE' });
            if (!response.ok) throw new Error(`Server error: ${response.status}`); // Handle server error
            return true; 
        } catch (error) {
            return false;
        }
    }

    // Initialize the page
    async function initializePage() {
        const [fetchedTags, fetchedCourses] = await Promise.all([
            fetchTags(),
            fetchMyCourses()
        ]);
        if (fetchedCourses === null) {
            console.error("Page initialization halted: could not fetch courses.");
            return;
        }
        TAGS = fetchedTags || [];
        coursesList = fetchedCourses || [];
        renderTagCheckboxes(); // Create tags list
        if (coursesList.length > 0) {
            coursesList.forEach((course) => renderCourseToScreen(course)); // Show the existed courses
        }
        calculateTotalPointsAndAverage();
        filterCourses();
    }

    initializePage();

    // Handle user logout
    document.getElementById('logout').addEventListener('click', function (event) {
        event.preventDefault();
        fetch('/logout', { // Send logout request to server
            method: 'POST', 
            headers: {
                'Content-Type': 'application/json' 
            }
        })
            .then(response => {
                if (response.ok) {
                    window.location.href = 'index.html'; // Redirect after logout
                } else {
                    alert('התנתקות נכשלה. אנא נסה שוב.');
                }
            })
            .catch(error => {
                alert('אירעה שגיאה. אנא נסה שוב מאוחר יותר.');
            });
    });

    // Handle create or update course
    document.getElementById("course-form").addEventListener("submit", async (e) => {
        e.preventDefault();
        const formCourse = createCourseFromForm();
        const idFromForm = currentEditingCard?.dataset.id; // Get course id
        let finalCourse;
        if (idFromForm) {
            finalCourse = await updateCourse(idFromForm, formCourse); // Update existing course
        } else {
            finalCourse = await addCourse(formCourse); // Create new course
        }
        if (finalCourse) {
            // Update coursesList array accordingly
            if (idFromForm) {
                const index = coursesList.findIndex((c) => c.id == idFromForm);
                if (index !== -1) coursesList[index] = finalCourse;
            } else {
                coursesList.push(finalCourse);
            }
            renderCourseToScreen(finalCourse);
            calculateTotalPointsAndAverage();
            filterCourses();
            resetForm();
            closeModal();
        } else {
            console.error("פעולת השמירה נכשלה, לא התקבל אובייקט מהשרת.");
        }
    });

    // Render a course card in the DOM (add or update)
    function renderCourseToScreen(course, container = document.getElementById("course-grid")) {
        const existing = container.querySelector(`.course-card[data-id="${course.id}"]`);
        const tagsHTML = (course.tags || []).map((tag) => `<span class="tag">${tag}</span>`).join("");
        const gradeDisplay = course.binaryChecked ? "עובר" : course.real_grade;
        const cardHTML = `
            <article class="course-card"
              data-id="${course.id}"
              data-name="${course.name}"
              data-year="${course.year}"
              data-semester="${course.semester}"
              data-tags="${(course.tags || []).join(",")}"
              data-credits="${course.credits}"
              data-grade="${course.grade}"
              data-real-grade="${course.real_grade}"
              data-binaryChecked="${course.binaryChecked}"
              data-bonus="${course.bonus}"
            >
              <h2>${course.name}</h2>
              <div class="course-summary">
                <span>שנה: ${course.year}<br>סמסטר: ${course.semester}</span>
                <div class="divider"></div>
                <span class="grade-credits">ציון: ${gradeDisplay}<br>נק"ז: ${course.credits}</span>
              </div>
              <div class="tags">${tagsHTML}</div>
              <button class="edit-course">✏️</button>
            </article>`;
        if (existing) { 
            // Replace card if it already exist, otherwise add it
            existing.outerHTML = cardHTML;
        } else {
            container.insertAdjacentHTML("beforeend", cardHTML);
        }
        const card = container.querySelector(`.course-card[data-id="${course.id}"]`); // Add edit button logic
        card.querySelector(".edit-course").addEventListener("click", () => {
            const id = card.dataset.id;
            const courseFromList = coursesList.find((c) => c.id == id);
            if (courseFromList) {
                populateFormFromCourseObject(courseFromList);
                currentEditingCard = card;
                document.getElementById("course-modal").classList.remove("hidden");
                const deleteB = document.getElementById("delete-btn");
                deleteB.classList.remove("locked");
                deleteB.disabled = false;
            }
        });
    }

    // Extracts course data from the form fields
    function createCourseFromForm() {
        // Get fields data
        const name = document.getElementById("course-name").value;
        const credits = parseFloat(document.getElementById("credits").value) || 0;
        // Validation credits
        if (credits > 10 || credits < 0) {
            alert("נקודות הזכות חייבות להיות בין 0 ל-10.");
            return null;
        }
        const binaryChecked = document.getElementById("binary-bonus").checked;
        const bonus = parseFloat(document.getElementById("bonus").value) || 0;
        const year = document.getElementById("year").value;
        const semester = document.getElementById("semester").value;
        const tags = [...document.querySelectorAll("#tag-options input:checked")].map(cb => cb.value);
        const components = [...document.querySelectorAll(".component-row")].map(row => ({
            component: row.querySelector(".comp-type").value,
            weight: parseFloat(row.querySelector(".comp-weight").value) || 0,
            grade: parseFloat(row.querySelector(".comp-grade").value) || 0,
        }));
        const manualGradeInput = document.getElementById("final-grade").value;
        const grade = parseFloat(manualGradeInput) || 0;
        const weightedResultText = document.getElementById("weighted-result").textContent;
        const real_grade = parseFloat(weightedResultText.replace(/[^\d.-]/g, "")) || 0;
        return {
            name,
            credits,
            grade,          
            real_grade,  
            year,
            semester,
            tags,
            components,
            binaryChecked,
            bonus
        };
    }

    // Loads data from course object into form
    function populateFormFromCourseObject(course) {
        document.getElementById("course-name").value = course.name;
        document.getElementById("final-grade").value = course.grade;
        document.getElementById("credits").value = course.credits;
        document.getElementById("year").value = course.year;
        document.getElementById("semester").value = course.semester;
        document.getElementById("binary-bonus").checked = course.binaryChecked;
        document.getElementById("bonus").value = course.bonus;
        const compContainer = document.getElementById("components-container");
        compContainer.innerHTML = "";
        if (course.components && Array.isArray(course.components)) {
            course.components.forEach((c) => addComponent(c.component, c.weight, c.grade));
        }
        const allCheckboxes = document.querySelectorAll("#tag-options input"); // Select matching tags
        allCheckboxes.forEach(cb => (cb.checked = (course.tags || []).includes(cb.value)));
        document.getElementById("selected-tags").textContent = (course.tags && course.tags.length) ? course.tags.join(", ") : "בחר תגיות...";
        calcWeighted();
    }

    // Setup filter dropdown
    function setupMultiSelect(dropdownId, listId, displayId, filterCallback) {
        const dropdown = document.getElementById(dropdownId);
        const list = document.getElementById(listId);
        const display = document.getElementById(displayId);
        dropdown.addEventListener("click", (e) => {
            if (e.target.tagName !== "INPUT") list.classList.toggle("hidden");
        });
        document.addEventListener("click", (e) => {
            if (!dropdown.contains(e.target)) list.classList.add("hidden");
        });
        list.addEventListener("input", () => {
            const selected = [...list.querySelectorAll("input:checked")].map(
                (cb) => cb.value
            );
            display.textContent = selected.length ? selected.join(", ") : "בחר...";
            filterCallback();
        });
    }

    // Calculate total credits and weighted avg grade
    function calculateTotalPointsAndAverage() {
        const courses = document.querySelectorAll(".course-card");
        let totalCredits = 0; // Count all credits 
        let weightedSum = 0; // Sum of grades X credits
        let creditsForAvg = 0; // Only non-binari credits use for avg
        courses.forEach((course) => {
            const binary = course.dataset.binarychecked === "true";
            const grade = parseFloat(course.dataset.realGrade);
            const credits = parseFloat(course.dataset.credits);
            // Always include in total credit
            if (!isNaN(credits)) {
                totalCredits += credits;
            }
            // Include in avg only if not binari
            if (!binary && !isNaN(grade) && !isNaN(credits)) {
                weightedSum += grade * credits;
                creditsForAvg += credits;
            }
        });
        document.getElementById("total-points").textContent = totalCredits;
        const avgGradeElem = document.getElementById("average-grade");
        avgGradeElem.textContent = creditsForAvg > 0 ? (weightedSum / creditsForAvg).toFixed(1) : "--";
    }

    // Render tag checkboxes in both filter and modal
    function renderTagCheckboxes() {
        const tagFilterContainer = document.getElementById("filter-tag-options"); // Tags for filter
        const tagModalContainer = document.getElementById("tag-options"); // Tags in popup
        tagFilterContainer.innerHTML = "";
        tagModalContainer.innerHTML = "";
        // Run for all tags and insert them in HTML
        TAGS.forEach((tag) => {
            var checkboxHTML = `<label><input type="checkbox" value="${tag}"> ${tag}</label>`;
            tagFilterContainer.innerHTML += checkboxHTML;
            tagModalContainer.innerHTML += checkboxHTML;
        });
    }
    setupMultiSelect("filter-tag-dropdown", "filter-tag-options", "filter-selected-tags", filterCourses);
    setupMultiSelect("filter-year-dropdown", "filter-year-options", "filter-selected-years", filterCourses);
    setupMultiSelect("filter-semester-dropdown", "filter-semester-options", "filter-selected-semesters", filterCourses);
    document.getElementById("filter-toggle").addEventListener("click", () => {
        document.getElementById("filter-options").classList.toggle("hidden");
    });

    document.getElementById("search").addEventListener("input", filterCourses);

    // Course filter function
    function filterCourses() {
        const tagVals = [...document.querySelectorAll("#filter-tag-options input:checked")].map(i => i.value);
        const yearVals = [...document.querySelectorAll("#filter-year-options input:checked")].map(i => i.value);
        const semVals = [...document.querySelectorAll("#filter-semester-options input:checked")].map(i => i.value);
        const searchVal = document.getElementById("search").value.toLowerCase();
        document.querySelectorAll(".course-card").forEach((course) => {
            const year = course.dataset.year;
            const sem = course.dataset.semester;
            const tags = course.dataset.tags.split(",");
            const title = course.querySelector("h2").textContent.toLowerCase();
            const matchTags = tagVals.length === 0 || tagVals.some(tag => tags.includes(tag));
            const matchYear = yearVals.length === 0 || yearVals.includes(year);
            const matchSem = semVals.length === 0 || semVals.includes(sem);
            const matchText = title.includes(searchVal);
            course.style.display = (matchTags && matchYear && matchSem && matchText) ? "" : "none"; // Show or hide course based on match
        });
    }
    document.getElementById("hamburger-btn").addEventListener("click", () => document.getElementById("nav-menu").classList.toggle("active"));
    const modal = document.getElementById("course-modal");

    // Popup open/close logic
    function openModal() {
        currentEditingCard = null;
        modal.classList.remove("hidden");
        resetForm();
        const deleteB = document.getElementById("delete-btn");
        deleteB.classList.add("locked");
        deleteB.disabled = true;
    }
    function closeModal() { 
        modal.classList.add("hidden"); 
    }

    document.getElementById("add-course").addEventListener("click", openModal); // Click on + button
    document.querySelector(".close-modal").addEventListener("click", closeModal); // click on X on popup
    modal.querySelector(".modal-overlay").addEventListener("click", closeModal); // click on grade area
    const dropdown = document.getElementById("tag-dropdown");
    const tagOptions = document.getElementById("tag-options");
    const selectedTagsDiv = document.getElementById("selected-tags");
    dropdown.addEventListener("click", (e) => {
        if (e.target.tagName !== "INPUT") tagOptions.classList.toggle("hidden");
        dropdown.classList.toggle("active");
    });
    tagOptions.addEventListener("change", () => {
        const selected = [...tagOptions.querySelectorAll("input:checked")].map(cb => cb.value);
        selectedTagsDiv.textContent = selected.length ? selected.join(", ") : "בחר תגיות...";
    });
    document.addEventListener("click", (e) => { if (!dropdown.contains(e.target)) tagOptions.classList.add("hidden"); });
    const compContainer = document.getElementById("components-container");
    document.getElementById("add-component").addEventListener("click", () => addComponent());

    // Add new component to course
    function addComponent(type = "מבחן", weight = "", grade = "") {
        const row = document.createElement("div");
        row.className = "component-row fade-in";
        row.innerHTML = `<div class="comp-field"><label>סוג רכיב<select class="comp-type"><option value="מבחן">מבחן</option><option value="עבודה">עבודה</option><option value="תרגיל">תרגיל</option><option value="בוחן">בוחן</option></select></label></div><div class="comp-field"><label>משקל<input type="number" class="comp-weight" min="0" max="100" value="${weight}"></label></div><div class="comp-field"><label>ציון<input type="number" class="comp-grade" min="0" max="100" value="${grade}"></label></div><button type="button" class="del-row">✕</button>`;
        compContainer.appendChild(row);
        row.querySelector(".comp-type").value = type;
        setTimeout(() => row.classList.remove("fade-in"), 300);
        calcWeighted();
    }
    // Remove component row and recalculate
    compContainer.addEventListener("click", (e) => {
        if (e.target.classList.contains("del-row")) { 
            e.target.parentElement.remove();
            if (!compContainer.querySelector(".component-row")) unlockFinalGrade(); // Allow manual grades if non components left
            updateWeightWarningVisibility();
            calcWeighted();
        }
    });

    document.getElementById("bonus").addEventListener("input", calcWeighted);
    compContainer.addEventListener("input", calcWeighted);
    const finalGradeInp = document.getElementById("final-grade");

    // Not allow to change the grades if there is component
    function lockFinalGrade() { 
        finalGradeInp.classList.add("locked"); finalGradeInp.disabled = true; 
    }

    // Revele grade
    function unlockFinalGrade() { 
        finalGradeInp.disabled = false; finalGradeInp.classList.remove("locked"); 
    }

    const warnBox = document.getElementById("weight-warning");
    const resultBox = document.getElementById("weighted-result");
    const saveBtn = document.getElementById("save-btn");

    document.getElementById("binary-bonus").addEventListener("change", calcWeighted);
    finalGradeInp.addEventListener("change", calcWeighted);

    // Show warning whether components exist
    function updateWeightWarningVisibility() {
        const hasComponents = compContainer.querySelectorAll(".component-row").length > 0;
        if (!hasComponents) warnBox.classList.add("hidden");
    }

    // Calculates weighted grade based on componenets + bonus
    function calcWeighted() {
        resultBox.classList.remove("hidden");
        const binaryChecked = document.getElementById("binary-bonus").checked;
        if (binaryChecked) {
            lockFinalGrade();
            resultBox.textContent = "ציון משוקלל : עובר";
            saveBtn.disabled = false;
            saveBtn.classList.remove("locked");
            return;
        }
        const rows = [...compContainer.children];
        let totalW = 0, wSum = 0;
        rows.forEach(r => {
            const w = +r.querySelector(".comp-weight").value || 0;
            const g = +r.querySelector(".comp-grade").value || 0;
            totalW += w;
            wSum += g * w;
        });
        if (rows.length) lockFinalGrade();
        else unlockFinalGrade();
        const bonus = +document.getElementById("bonus").value || 0;
        if (totalW > 0 && totalW !== 100) {
            warnBox.classList.remove("hidden");
            saveBtn.disabled = true;
            saveBtn.classList.add("locked");
            resultBox.textContent = "(סה״כ משקל לא 100%)";
        } else {
            warnBox.classList.add("hidden");
            saveBtn.disabled = false;
            saveBtn.classList.remove("locked");

            let weighted;
            if (rows.length) {
                weighted = (wSum / 100 + bonus);
            } else {
                weighted = (parseFloat(finalGradeInp.value) + bonus);
            }
            resultBox.textContent = "ציון משוקלל : " + (isNaN(weighted) ? "" : weighted.toFixed(1));
        }
    }

    // Reset form
    function resetForm() {
        document.getElementById("course-form").reset();
        compContainer.innerHTML = "";
        calcWeighted();
        resultBox.textContent = "ציון משוקלל : 0";
        selectedTagsDiv.textContent = "בחר תגיות...";
        [...tagOptions.querySelectorAll("input:checked")].forEach(cb => (cb.checked = false));
    }

    document.getElementById("delete-btn").addEventListener("click", async () => { // Delete the currently edited course
        if (currentEditingCard && confirm("מחיקה?")) {
            const idToDelete = currentEditingCard.dataset.id;
            const success = await deleteCourse(idToDelete);
            if (success) { // Remove from screen
                coursesList = coursesList.filter(c => c.id != idToDelete);
                currentEditingCard.remove();
                currentEditingCard = null;
                calculateTotalPointsAndAverage();
                filterCourses();
                closeModal();
            }
        }
    });

    const yearSpan = document.getElementById("year1");
    if (yearSpan) {
        yearSpan.textContent = new Date().getFullYear();
    }
});