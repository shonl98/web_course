// ===== Hamburger Menu Toggle =====
// Handles opening/closing the mobile navigation menu when hamburger is clicked
document.getElementById("hamburger-btn")
  ?.addEventListener("click", () => {
    document.getElementById("nav-menu").classList.toggle("active");
  });

// ===== Update Year in Footer =====
// Sets the current year dynamically in the footer 
const yearSpan = document.getElementById("year");
if (yearSpan) {
  yearSpan.textContent = new Date().getFullYear();
}

// ===== Login Form Validation & Error Bubbles =====
document.addEventListener('DOMContentLoaded', () => {
  const emailInput = document.getElementById('login-email');
  const passwordInput = document.getElementById('login-password');
  const loginForm = document.getElementById('loginForm');

  // Removes all existing error bubbles from the page
  function clearErrors() {
    document.querySelectorAll('.input-error-bubble').forEach(el => el.remove());
  }

  // Displays an error bubble next to a specific input element
  function showError(inputEl, message) {
    if (inputEl.nextElementSibling && inputEl.nextElementSibling.classList.contains('input-error-bubble')) {
      inputEl.nextElementSibling.remove();
    }
    const bubble = document.createElement('div');
    bubble.className = 'input-error-bubble';
    bubble.textContent = message;
    inputEl.after(bubble);
  }

  // Validates email and returns a specific error meesage (if any)
  function validateEmail(email) {
    if (!email.includes('@')) return "האימייל חייב לכלול @";
    if (email.length < 15) return "האימייל חייב לכלול מעל 15 תווים";
    if (!/^[a-zA-Z0-9@._-]+$/.test(email)) return "האימייל חייב להיות באנגלית בלבד ובתווים תקניים";
    return "";
  }

  // Validates passward length (6+ characters)
  function validatePassword(password) {
    return password.length >= 6 ? "" : "הסיסמה חייבת לכלול 6 תווים לפחות";
  }

  // Login button click handler - runs all validations and shows bubbles if needed
  loginForm?.addEventListener('submit', async function (e) {
    e.preventDefault();
    clearErrors();
    let isValid = true;
    const passwordMsg = validatePassword(passwordInput.value); // Validate password
    if (passwordMsg) {
      showError(passwordInput, passwordMsg);
      isValid = false;
    }
    if (!isValid) return;
    try { // Send login request to server
      const res = await fetch('/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: `email=${encodeURIComponent(emailInput.value)}&password=${encodeURIComponent(passwordInput.value)}`
      });
      const data = await res.json();
      if (data.success) {
        window.location.href = data.redirect; // Redirect after successful login
      } else {
        showError(passwordInput, data.message || 'שגיאה כללית');
      }
    } catch (err) {
      showError(passwordInput, 'שגיאה בשרת. נסה שוב מאוחר יותר');
    }
  });
});

